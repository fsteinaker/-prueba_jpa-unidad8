package com.prueba_jpa.prueba_jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
